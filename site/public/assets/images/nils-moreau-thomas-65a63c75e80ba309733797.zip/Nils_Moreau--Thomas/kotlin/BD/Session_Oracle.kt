package BD
import java.sql.*

class Session_Oracle(val username : String,val password : String) {
    var conn: Connection? = null
    init {
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver").newInstance()
            conn = DriverManager.getConnection("jdbc:oracle:thin:@172.26.82.31:1521:xe",username, password)
            println("connexion réussie")
        } catch (e: SQLException) {
            println(e.errorCode)//numéro d'erreur
            println(e.message)// message d'erreur qui provient d'oracle,
        }
    }
    fun getConnectionOracle(): Connection? = conn
}