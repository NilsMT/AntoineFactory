package BEAN

class Offre_stage(val numoffre : Int, val nument : Int, val libelle : String,val remuneration : Int) {
    override fun toString(): String {
        return "${this.numoffre} ${this.nument} ${this.libelle} ${this.remuneration}"
    }
}