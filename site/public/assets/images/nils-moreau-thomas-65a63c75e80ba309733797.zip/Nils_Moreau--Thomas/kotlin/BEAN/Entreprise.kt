package BEAN

class Entreprise(val nument : Int, val noment : String) {
    override fun toString(): String {
        return "${this.nument} ${this.noment}"
    }
}