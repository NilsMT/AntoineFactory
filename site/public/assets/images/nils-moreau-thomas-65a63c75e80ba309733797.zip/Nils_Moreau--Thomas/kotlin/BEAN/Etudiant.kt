package BEAN

class Etudiant(val numetudiant : Int,val nomeetudiant : String) {
    override fun toString(): String {
        return "${this.numetudiant} ${this.nomeetudiant}"
    }
}