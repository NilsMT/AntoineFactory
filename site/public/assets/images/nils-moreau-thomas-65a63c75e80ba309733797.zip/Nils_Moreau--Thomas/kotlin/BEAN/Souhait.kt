package BEAN

class Souhait(val numetudiant : Int, val numoffre : Int) {
    override fun toString(): String {
        return "${this.numetudiant} ${this.numoffre}"
    }
}