package BEAN

class Affecte_stage_etudiant(val numetudiant : Int, val numoffre : Int) {
    override fun toString(): String {
        return "${this.numetudiant} ${this.numoffre}"
    }
}