package DAO

import BD.Session_Oracle
import BEAN.Entreprise
import BEAN.Etudiant
import BEAN.Offre_stage
import java.sql.*

class DAOStage(ss : Session_Oracle) {
    var session: Session_Oracle? = null
    init {
        this.session=ss
    }

    fun supprimer_affecte_stage(etu : Etudiant, offre : Offre_stage) {
        var conn: Connection? = null
        conn= session?.getConnectionOracle()
        val requete ="DELETE FROM affecte_stage_etudiant a WHERE ?=a.numetudiant and ?=a.numoffre"
        try {
            val stmt: PreparedStatement = conn!!.prepareStatement(requete)
            stmt.setInt(1,etu.numetudiant)
            stmt.setInt(2,offre.numoffre)
            stmt.execute()
            val result: ResultSet = stmt.executeQuery(requete)
        }
        catch(e: SQLException){
            println(e.errorCode)
            println(e.message)
        }
    }

    fun creation_offre_stage(liste : Array<Offre_stage>) {
        var conn: Connection? = null
        conn= session?.getConnectionOracle()
        liste.forEach {
            val requete ="call MAJ_Lecture.ajout_offre(${it.numoffre},${it.nument},${it.libelle},${it.remuneration})"
            try {
                val stmt: Statement = conn!!.createStatement()
                stmt.executeUpdate(requete)
            }
            catch(e: SQLException){
                println(e.errorCode)
                println(e.message)
            }
        }
    }

    fun creation_offre_stage_prepared(liste : Array<Offre_stage>) {
        var conn: Connection? = null
        conn= session?.getConnectionOracle()
        liste.forEach {
            val requete ="call MAJ_Lecture.ajout_offre(?,?,?,?)"
            try {
                val stmt: PreparedStatement = conn!!.prepareCall(requete)
                stmt.setInt(1,it.numoffre)
                stmt.setInt(2,it.nument)
                stmt.setString(3,it.libelle)
                stmt.setInt(4,it.remuneration)
                stmt.execute()
                val result: ResultSet = stmt.executeQuery(requete)
            }
            catch(e: SQLException){
                println(e.errorCode)
                println(e.message)
            }
        }
    }
    fun lecture_liste(ent : Entreprise) : List<Offre_stage>? {
        var conn: Connection? = null
        conn= session?.getConnectionOracle()
        val requete ="SELECT * FROM offre_stage o WHERE o.nument=${ent.nument}"
        val lst = mutableListOf<Offre_stage>()
        try {
            val stmt: Statement = conn!!.createStatement()
            stmt.execute(requete)
            val result: ResultSet = stmt.executeQuery(requete)

            while (result!!.next()) {

                val o = result.getInt("numoffre")
                val e=result.getInt("nument")
                val l = result.getString("libelle")
                val r = result.getInt("remuneration")
                lst.add(Offre_stage(o,e,l,r))
            }
            result.close()
            return lst.toList()
        }
        catch(e: SQLException){
            println(e.errorCode)
            println(e.message)
        }
        return null
    }
}