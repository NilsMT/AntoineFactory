import BD.Session_Oracle
import BEAN.Entreprise
import BEAN.Etudiant
import BEAN.Offre_stage
import DAO.DAOStage

fun main() {
    val ss = Session_Oracle("s3b10a","lol123")
    val dao = DAOStage(ss)
    val etutest = Etudiant(12,"Rayan") //fidèle au données de la BD
    val offretest = Offre_stage(701,50,"Carte fidelite",600) //fidèle au données de la BD

    println("============== supprimer_affecte_stage")
    dao.supprimer_affecte_stage(etutest,offretest) //supprime la 12-701
    println("il se supprime quand même")

    println("============== creation_offre_stage")
    val listetest = arrayOf(offretest)
    dao.creation_offre_stage(listetest)
    println("il se crée quand même")

    println("============== creation_offre_stage_prepared")
    dao.creation_offre_stage_prepared(listetest) //il existe déjà donc il y a une erreur
    println("il existe déjà donc il y a une erreur")

    println("============== lecture_liste")
    val enttest = Entreprise(50,"Carrefour") //fidèle au données de la BD
    dao.lecture_liste(enttest)!!.forEach { println(it.toString()) } //on considère que c'est non-nul
}